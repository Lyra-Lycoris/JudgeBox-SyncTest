package t01_date_after

func solve(y: Int64, m: Int64, d: Int64, k: Int64): String {
    // TODO: 返回再过 k 天之后的日期，格式 YYYY-MM-DD
return ""
}
