    static String solve(long y, long m, long d, long k) {
        // TODO: 返回再过 k 天之后的日期，格式 YYYY-MM-DD
        return "";
    }
