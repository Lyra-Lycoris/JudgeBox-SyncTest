#include <bits/stdc++.h>
using namespace std;

string solve(long long y, long long m, long long d, long long k);

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    long long y; cin >> y;
    long long m; cin >> m;
    long long d; cin >> d;
    long long k; cin >> k;
    string answer = solve(y, m, d, k);
    cout << answer << '\n';
    return 0;
}
