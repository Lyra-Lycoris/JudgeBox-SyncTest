import sys


def solve(y: int, m: int, d: int, k: int) -> str:
    # TODO: 返回再过 k 天之后的日期，格式 YYYY-MM-DD
    return ""
