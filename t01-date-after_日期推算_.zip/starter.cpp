#include <bits/stdc++.h>
using namespace std;

string solve(long long y, long long m, long long d, long long k) {
    // TODO: 返回再过 k 天之后的日期，格式 YYYY-MM-DD
return "";
}
