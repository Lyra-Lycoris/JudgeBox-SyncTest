import sys


def main():
    data = sys.stdin.buffer.read().split()
    pos = 0
    y = int(data[pos]); pos += 1
    m = int(data[pos]); pos += 1
    d = int(data[pos]); pos += 1
    k = int(data[pos]); pos += 1
    print(solve(y, m, d, k))


main()
