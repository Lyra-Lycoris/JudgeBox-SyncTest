package t05_range_sum_queries

func solve(n: Int64, a: Array<Int64>, l: Int64, r: Int64): Int64 {
    // TODO: 返回每组数据中 a[l..r] 的元素和，输入有多组
return 0
}
