    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in), 1 << 16);
        StringBuilder buffer = new StringBuilder();
        char[] chunk = new char[1 << 16];
        int read;
        while ((read = br.read(chunk)) > 0) buffer.append(chunk, 0, read);
        StringTokenizer st = new StringTokenizer(buffer.toString());
        int T = Integer.parseInt(st.nextToken());
        for (int __case = 0; __case < T; ++__case) {
            long n = Long.parseLong(st.nextToken());
            long[] a = new long[(int) (n)];
            for (int i = 0; i < a.length; ++i) a[i] = Long.parseLong(st.nextToken());
            long l = Long.parseLong(st.nextToken());
            long r = Long.parseLong(st.nextToken());
            System.out.println(solve(n, a, l, r));
        }
    }
