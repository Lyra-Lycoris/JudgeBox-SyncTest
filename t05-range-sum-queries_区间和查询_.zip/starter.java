    static long solve(long n, long[] a, long l, long r) {
        // TODO: 返回每组数据中 a[l..r] 的元素和，输入有多组
        return 0;
    }
