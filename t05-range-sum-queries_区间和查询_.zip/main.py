import sys


def main():
    data = sys.stdin.buffer.read().split()
    pos = 0
    t = int(data[pos]); pos += 1
    for _ in range(t):
        n = int(data[pos]); pos += 1
        a = [int(x) for x in data[pos:pos + n]]; pos += n
        l = int(data[pos]); pos += 1
        r = int(data[pos]); pos += 1
        print(solve(n, a, l, r))


main()
