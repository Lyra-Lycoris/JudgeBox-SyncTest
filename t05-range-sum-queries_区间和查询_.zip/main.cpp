#include <bits/stdc++.h>
using namespace std;

long long solve(long long n, const vector<long long>& a, long long l, long long r);

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int T; cin >> T;
    while (T--) {
        long long n; cin >> n;
        vector<long long> a(n); for (auto& x : a) cin >> x;
        long long l; cin >> l;
        long long r; cin >> r;
        long long answer = solve(n, a, l, r);
        cout << answer << '\n';
    }
    return 0;
}
