#include <bits/stdc++.h>
using namespace std;

long long solve(long long n, const vector<long long>& a, long long l, long long r) {
    // TODO: 返回每组数据中 a[l..r] 的元素和，输入有多组
return 0;
}
