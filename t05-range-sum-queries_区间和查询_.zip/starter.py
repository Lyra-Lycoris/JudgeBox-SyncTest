import sys


def solve(n: int, a: list[int], l: int, r: int) -> int:
    # TODO: 返回每组数据中 a[l..r] 的元素和，输入有多组
    return 0
