    static long solve(long n, long[] g, long m, long[] s) {
        // TODO: 返回最多能满足的孩子个数
        return 0;
    }
