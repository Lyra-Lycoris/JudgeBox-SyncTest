import sys


def solve(n: int, g: list[int], m: int, s: list[int]) -> int:
    # TODO: 返回最多能满足的孩子个数
    return 0
