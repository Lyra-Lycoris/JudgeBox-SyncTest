package t03_assign_cookies

func solve(n: Int64, g: Array<Int64>, m: Int64, s: Array<Int64>): Int64 {
    // TODO: 返回最多能满足的孩子个数
return 0
}
