#include <bits/stdc++.h>
using namespace std;

long long solve(long long n, const vector<long long>& g, long long m, const vector<long long>& s) {
    // TODO: 返回最多能满足的孩子个数
return 0;
}
