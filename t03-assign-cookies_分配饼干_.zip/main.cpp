#include <bits/stdc++.h>
using namespace std;

long long solve(long long n, const vector<long long>& g, long long m, const vector<long long>& s);

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    long long n; cin >> n;
    vector<long long> g(n); for (auto& x : g) cin >> x;
    long long m; cin >> m;
    vector<long long> s(m); for (auto& x : s) cin >> x;
    long long answer = solve(n, g, m, s);
    cout << answer << '\n';
    return 0;
}
