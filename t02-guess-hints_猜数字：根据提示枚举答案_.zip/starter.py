import sys


def solve(n: int, k: int, guesses: list[int], exact: list[int], loose: list[int]) -> list[int]:
    # TODO: 返回唯一满足全部提示的 n 位密码，按位输出（允许前导零）
    return []
