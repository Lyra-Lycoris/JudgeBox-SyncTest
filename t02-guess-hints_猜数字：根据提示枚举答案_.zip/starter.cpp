#include <bits/stdc++.h>
using namespace std;

vector<long long> solve(long long n, long long k, const vector<long long>& guesses, const vector<long long>& exact, const vector<long long>& loose) {
    // TODO: 返回唯一满足全部提示的 n 位密码，按位输出（允许前导零）
return {};
}
