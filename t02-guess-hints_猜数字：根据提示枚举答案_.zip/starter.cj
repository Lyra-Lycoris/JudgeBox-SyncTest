package t02_guess_hints

func solve(n: Int64, k: Int64, guesses: Array<Int64>, exact: Array<Int64>, loose: Array<Int64>): Array<Int64> {
    // TODO: 返回唯一满足全部提示的 n 位密码，按位输出（允许前导零）
return Array<Int64>()
}
