#include <bits/stdc++.h>
using namespace std;

vector<long long> solve(long long n, long long k, const vector<long long>& guesses, const vector<long long>& exact, const vector<long long>& loose);

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    long long n; cin >> n;
    long long k; cin >> k;
    vector<long long> guesses(k); for (auto& x : guesses) cin >> x;
    vector<long long> exact(k); for (auto& x : exact) cin >> x;
    vector<long long> loose(k); for (auto& x : loose) cin >> x;
    vector<long long> answer = solve(n, k, guesses, exact, loose);
    for (size_t i = 0; i < answer.size(); ++i) cout << answer[i] << (i + 1 == answer.size() ? '\n' : ' ');
    if (answer.empty()) cout << '\n';
    return 0;
}
