    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in), 1 << 16);
        StringBuilder buffer = new StringBuilder();
        char[] chunk = new char[1 << 16];
        int read;
        while ((read = br.read(chunk)) > 0) buffer.append(chunk, 0, read);
        StringTokenizer st = new StringTokenizer(buffer.toString());
        long n = Long.parseLong(st.nextToken());
        long k = Long.parseLong(st.nextToken());
        long[] guesses = new long[(int) (k)];
        for (int i = 0; i < guesses.length; ++i) guesses[i] = Long.parseLong(st.nextToken());
        long[] exact = new long[(int) (k)];
        for (int i = 0; i < exact.length; ++i) exact[i] = Long.parseLong(st.nextToken());
        long[] loose = new long[(int) (k)];
        for (int i = 0; i < loose.length; ++i) loose[i] = Long.parseLong(st.nextToken());
        long[] __answer = solve(n, k, guesses, exact, loose);
        StringBuilder __sb = new StringBuilder();
        for (int i = 0; i < __answer.length; ++i) { if (i > 0) __sb.append(' '); __sb.append(__answer[i]); }
        System.out.println(__sb);
    }
