    static long[] solve(long n, long k, long[] guesses, long[] exact, long[] loose) {
        // TODO: 返回唯一满足全部提示的 n 位密码，按位输出（允许前导零）
        return new long[0];
    }
