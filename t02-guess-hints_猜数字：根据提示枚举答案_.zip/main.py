import sys


def main():
    data = sys.stdin.buffer.read().split()
    pos = 0
    n = int(data[pos]); pos += 1
    k = int(data[pos]); pos += 1
    guesses = [int(x) for x in data[pos:pos + k]]; pos += k
    exact = [int(x) for x in data[pos:pos + k]]; pos += k
    loose = [int(x) for x in data[pos:pos + k]]; pos += k
    print(' '.join(str(x) for x in solve(n, k, guesses, exact, loose)))


main()
