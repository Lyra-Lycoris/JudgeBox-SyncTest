import sys


def solve(n: int, l: list[int], r: list[int], m: int) -> int:
    # TODO: 返回覆盖 [0, m] 所需的最少区间数，无解返回 -1
    return 0
