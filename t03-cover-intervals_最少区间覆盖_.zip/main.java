    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in), 1 << 16);
        StringBuilder buffer = new StringBuilder();
        char[] chunk = new char[1 << 16];
        int read;
        while ((read = br.read(chunk)) > 0) buffer.append(chunk, 0, read);
        StringTokenizer st = new StringTokenizer(buffer.toString());
        long n = Long.parseLong(st.nextToken());
        long[] l = new long[(int) (n)];
        for (int i = 0; i < l.length; ++i) l[i] = Long.parseLong(st.nextToken());
        long[] r = new long[(int) (n)];
        for (int i = 0; i < r.length; ++i) r[i] = Long.parseLong(st.nextToken());
        long m = Long.parseLong(st.nextToken());
        System.out.println(solve(n, l, r, m));
    }
