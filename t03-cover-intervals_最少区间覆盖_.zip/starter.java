    static long solve(long n, long[] l, long[] r, long m) {
        // TODO: 返回覆盖 [0, m] 所需的最少区间数，无解返回 -1
        return 0;
    }
