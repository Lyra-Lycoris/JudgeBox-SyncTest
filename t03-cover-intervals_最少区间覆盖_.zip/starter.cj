package t03_cover_intervals

func solve(n: Int64, l: Array<Int64>, r: Array<Int64>, m: Int64): Int64 {
    // TODO: 返回覆盖 [0, m] 所需的最少区间数，无解返回 -1
return 0
}
