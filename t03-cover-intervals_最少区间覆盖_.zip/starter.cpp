#include <bits/stdc++.h>
using namespace std;

long long solve(long long n, const vector<long long>& l, const vector<long long>& r, long long m) {
    // TODO: 返回覆盖 [0, m] 所需的最少区间数，无解返回 -1
return 0;
}
